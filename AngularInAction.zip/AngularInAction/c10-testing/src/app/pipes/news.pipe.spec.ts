import { NewsPipe } from './news.pipe';

describe('NewsPipe', () => {

});
