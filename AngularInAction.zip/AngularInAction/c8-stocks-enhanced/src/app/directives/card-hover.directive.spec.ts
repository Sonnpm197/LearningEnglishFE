import { CardHoverDirective } from './card-hover.directive';

describe('CardHoverDirective', () => {
  it('should create an instance', () => {
    const directive = new CardHoverDirective();
    expect(directive).toBeTruthy();
  });
});
