import { CardTypeDirective } from './card-type.directive';

describe('CardTypeDirective', () => {
  it('should create an instance', () => {
    const directive = new CardTypeDirective();
    expect(directive).toBeTruthy();
  });
});
