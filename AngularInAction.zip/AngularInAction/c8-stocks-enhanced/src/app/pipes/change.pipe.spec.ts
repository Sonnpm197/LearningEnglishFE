import { ChangePipe } from './change.pipe';

describe('ChangePipe', () => {
  it('create an instance', () => {
    const pipe = new ChangePipe();
    expect(pipe).toBeTruthy();
  });
});
