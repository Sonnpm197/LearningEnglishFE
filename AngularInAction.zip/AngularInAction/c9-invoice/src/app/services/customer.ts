export class Customer {
  email: string;
  id: number;
  name: string;
  phone: string;
}
