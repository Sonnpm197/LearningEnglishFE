import { PhoneDirective } from './phone.directive';

describe('PhoneDirective', () => {
  it('should create an instance', () => {
    const directive = new PhoneDirective();
    expect(directive).toBeTruthy();
  });
});
